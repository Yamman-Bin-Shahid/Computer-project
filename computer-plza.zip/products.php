<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="./icon.png">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
  <!-- CSS -->
  <link rel="stylesheet" href="./bootstrap-italia/css/bootstrap-italia.min.css" />
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
  <!-- JQuery -->
  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
  <!-- Popper.js -->
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
  <!-- JavaScript -->
  <script src="./bootstrap-italia/js/bootstrap-italia.bundle.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">


  <title>Gestionale Computer Plaza</title>
  <link rel="stylesheet" href="./style.css">
</head>

<body>
  <header>
    <nav class="site-header sticky-top py-1">
      <div class="container d-flex flex-column flex-md-row justify-content-between align-items-center">
        <a class="py-2 d-flex text-decoration-none" href="#">
          <img width="150" height="50" src="./icon.png"></img>
          <h2 class="title" style="color: #9ac00b">Computer Plaza</h2>
        </a>
        <a class="py-2 d-none d-md-inline-block" style="color: #9ac00b" href="./">Home</a>
        <a class="py-2 d-none d-md-inline-block" style="color: #9ac00b" href="./products.php">Prodotti</a>
        <a class="py-2 d-none d-md-inline-block" style="color: #9ac00b" href="./costumers.php">Clienti</a>
        <a class="py-2 d-none d-md-inline-block" style="color: #9ac00b" href="./orders.php">Ordini</a>

      </div>
    </nav>
  </header>





  <?php
  include('./phpqrcode/qrlib.php');
  // Specifica i dati dell'API di WooCommerce
  $url = 'https://servizi.wpschool.it/wp-json/wc/v3/products';
  $username = 'ck_fe204273ad276fc9c7a5e36ad96765b26bbce88b';
  $password = 'cs_1ceae7502d5becd86f21d13c215d97f49d8989ff';


  // Crea un'istanza di cURL
  $ch = curl_init();

  // Imposta le opzioni di cURL
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_USERPWD, $username . ':' . $password);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

  // Esegui la chiamata API
  $response = curl_exec($ch);


  // Gestisci la risposta dell'API
  if ($response === false) {
    $error = curl_error($ch);
    // Gestisci l'errore
  } else {
    $products = json_decode($response);
  }
  // Chiudi la connessione cURL
  curl_close($ch);
  $title = 'Prodotti';
  $content_filter[] = 'adjust_markup';

  function chiamaApivariations($id)
  {
    $username = 'ck_fe204273ad276fc9c7a5e36ad96765b26bbce88b';
    $password = 'cs_1ceae7502d5becd86f21d13c215d97f49d8989ff';
    $ch = curl_init();
    // Imposta le opzioni di cURL per gli articoli variabili
    $url = 'https://servizi.wpschool.it/wp-json/wc/v3/products/' . $id . '/variations';
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_USERPWD, $username . ':' . $password);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    // Esegui la chiamata API
    $response = curl_exec($ch);

    // Gestisci la risposta dell'API
    if ($response === false) {
      $error = curl_error($ch);
      // Gestisci l'errore
    } else {
      $variations = json_decode($response);
    }
    return $variations;
  }
  ?>

  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary" style="color: #9ac00b!important">Elenco prodotti magazzino</h6>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <?php echo '<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">';
        echo '<thead>';
        echo '<tr>';
        echo '<th>ID</th>';
        echo '<th>sku</th>';
        echo '<th>Nome</th>';
        echo '<th>Prezzo</th>';
        echo '<th>Giacenza</th>';
        echo '<th>Variazione</th>';
        echo '<th>Edit</th>';
        echo '<th>QR</th>';
        echo '</tr>';
        echo '</thead>';

        echo '<tfoot>';
        echo '<tr>';
        echo '<th>ID</th>';
        echo '<th>sku</th>';
        echo '<th>Nome</th>';
        echo '<th>Prezzo</th>';
        echo '<th>Giacenza</th>';
        echo '<th>Variazione</th>';
        echo '<th>Edit</th>';
        echo '<th>QR</th>';
        echo '</tr>';
        echo '</tfoot>';

        echo '<tbody>';
        ?>

        <?php
        foreach ($products as $product) {
          // Check if the product is variable
          if ($product->type == 'variable') {
            $name = $product->name;
            $variations = chiamaApivariations($product->id);
            //print_r($variations);
            foreach ($variations as $variation) {
              // Retrieve the SKU and other parameters for the variation
              $text = $variation->sku;
              $new_sku = str_replace(' ', '', $sku);
              echo '<tr>';
              echo '<td>' . $variation->id . '</td>';
              echo '<td>' . $variation->sku . '</td>';
              echo '<td>' . $name .  '</td>';
              echo '<td>' . $variation->price . '</td>';
              echo '<td>' . $variation->stock_quantity . '</td>';
              echo '<td>' . $variation->attributes[0]->name . "  " . $variation->attributes[0]->option . '</td>'; ?>
              <td>
                <button type="button" class="btn" data-toggle="modal" data-target="#exampleModal-<?php echo $variation->id; ?>"><i>Modifica</i></button>
                <div class="modal fade" id="exampleModal-<?php echo $variation->id; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                  <div class="modal-dialog" role="document">
                    <div class="modal-content">
                      <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Aggiorna <?php echo $name; ?></h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <form class="form" action="./edit_product_variation.php" method="post">
                          <div class="text-danger font-weight-bold">
                            ID : <?php echo $variation->id ?>
                            <input type="hidden" name="id" value="<?php echo $variation->id ?>">
                            <input type="hidden" name="product_id" value="<?php echo $product->id ?>">
                          </div>                        
                          <div class="form-group">
                            Nome:
                            <input class="form-control" name="up_name" value="<?php echo $product->name; ?>">
                          </div>
                          <div class="form-group">
                            Variazione:
                            <input class="form-control" name="attribute" value="<?php echo $variation->attributes[0]->option; ?>">
                          </div>
                          <div class="form-group">
                            Prezzo:
                            <input class="form-control" name="prezzo" value="<?php echo $variation->price; ?>">
                          </div>
                          <div class="form-group">
                            Giacenza:
                            <input class="form-control" name="giacenza" value="<?php echo $variation->stock_quantity; ?>">
                          </div>
                      </div>
                      <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                      </div>
                      </form>
                    </div>
                  </div>
                </div>
      </div>
      <!-- <a class="delete text-danger" title="Delete" data-toggle="tooltip" manca il maggiore ?php echo 'href="./delete_product_variation.php?id=' . $product->id . '&variation_id=' . $variation->id . '"' ?>><i class="material-icons">Delete</i></a> -->
      <a href="delete_product_variable.php?id=<?php echo $product->id; ?>&variable_id=<?php echo $variation->id;?>" class="btn btn-danger"><i class="bi bi-trash3">Cancella</i></a>
      </td>
      <td>

        <?php
              $sku = $product->sku;
              $name = $product->name;
              $option = $product->option;
              $qrtext = $sku . " " . $name . " " . $option;
              $qrimage = $sku . ".png";
              QRCODE::png($qrtext,  $qrimage, 1, 2);
        ?>
        <button type="button" class="btn" data-toggle="modal" data-target=".bd-example-modal-sm"><img src="<?php echo $qrimage ?>" /></button>
        <div class="modal fade bd-example-modal-sm" id="prova" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
          <div class="modal-dialog modal-sm">
            <div class="modal-content">
              <img src="<?php echo $qrimage ?>" />
            </div>
          </div>
        </div>
      </td>

    <?php echo '</tr>';
            }
          } else {

            // Stampa le informazioni del prodotto
            $text = $product->sku;

            echo '<tr>';
            echo '<td>' . $product->id . '</td>';
            echo '<td>' . $product->sku . '</td>';
            echo '<td>' . $product->name .  '</td>';
            echo '<td>' . $product->price . '</td>';
            echo '<td>' . $product->stock_quantity . '</td>';
    ?>
    <td></td>
    <td>
      <button type="button" class="btn" data-toggle="modal" data-target="#exampleModal-<?php echo $product->id; ?>"><i>Modifica</i></button>
      <div class="modal fade" id="exampleModal-<?php echo $product->id; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Aggiorna <?php echo $product->name; ?></h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <form class="form" action="./edit_product.php" method="post">
                <div class="text-danger font-weight-bold">
                  ID : <?php echo $product->id ?>
                  <input type="hidden" name="up_id" value="<?php echo $product->id ?>">
                </div>              
                <div class="form-group">
                  Nome:
                  <input class="form-control" name="up_name" value="<?php echo $product->name ?>">
                </div>

                <div class="form-group">
                  Prezzo:
                  <input class="form-control" name="up_price" value="<?php echo $product->price ?>">
                </div>
                <div class="form-group">
                  Giacenza:
                  <input class="form-control" name="up_stock_quantity" value="<?php echo $product->stock_quantity ?>">
                </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
            </form>
          </div>
        </div>
      </div>
    </div>
    <a href="delete_product.php?id=<?php echo $product->id;?>" class="btn btn-danger"><i>Cancella</i></a>
    </td>
    <td>

      <?php
            $sku = $product->sku;
            $name = $product->name;
            $option = $product->option;
            $qrtext = $sku . " " . $name . " " . $option;
            $qrimage = $sku . ".png";
            QRCODE::png($qrtext,  $qrimage, 1, 2);
        ?>
      
      <button type="button" class="btn" data-toggle="modal" data-target=".bd-example-modal-sm"><img src="<?php echo $qrimage ?>" /></button>
      <div class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm">
          <div class="modal-content">
            <img src="<?php echo $qrimage ?>" />
          </div>
        </div>
      </div>
    </td>

<?php echo '</tr>';
          }
        }

        echo '</tbody>';
        echo '</table>';


?>
  </div>
  </div>
  </div>






  <footer class="mainfooter" role="contentinfo">
    <div class="footer-middle">
      <div class="container">
        <div class="row">
          <div class="col-md-3 col-sm-6">
            <!--Column1-->
            <div class="footer-pad">
              <h4>Heading 1</h4>
              <ul class="list-unstyled">
                <li><a href="#"></a></li>
                <li><a href="#">Payment Center</a></li>
                <li><a href="#">Contact Directory</a></li>
                <li><a href="#">Forms</a></li>
                <li><a href="#">News and Updates</a></li>
                <li><a href="#">FAQs</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md-3 col-sm-6">
            <!--Column1-->
            <div class="footer-pad">
              <h4>Heading 2</h4>
              <ul class="list-unstyled">
                <li><a href="#">Website Tutorial</a></li>
                <li><a href="#">Accessibility</a></li>
                <li><a href="#">Disclaimer</a></li>
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">FAQs</a></li>
                <li><a href="#">Webmaster</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md-3 col-sm-6">
            <!--Column1-->
            <div class="footer-pad">
              <h4>Heading 3</h4>
              <ul class="list-unstyled">
                <li><a href="#">Parks and Recreation</a></li>
                <li><a href="#">Public Works</a></li>
                <li><a href="#">Police Department</a></li>
                <li><a href="#">Fire</a></li>
                <li><a href="#">Mayor and City Council</a></li>
                <li>
                  <a href="#"></a>
                </li>
              </ul>
            </div>
          </div>
          <div class="col-md-3 mb-3">
            <h4>Follow Us</h4>
            <ul class="social-network social-circle">
              <li><a href="#" class="icoFacebook" title="Facebook"><i class="fa fa-facebook"></i></a></li>
              <li><a href="#" class="icoLinkedin" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
            </ul>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 copy">
            <p class="text-center">&copy; Copyright 2018 - Company Name. All rights reserved.</p>
          </div>
        </div>
      </div>
    </div>
  </footer>


  <!-- Bootstrap core JavaScript
    ================================================== -->
  <!-- Placed at the end of the document so the pages load faster -->
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script>
    window.jQuery || document.write('<script src="../../../../assets/js/vendor/jquery-slim.min.js"><\/script>')
  </script>
  <script src="../../../../assets/js/vendor/popper.min.js"></script>
  <script src="../../../../dist/js/bootstrap.min.js"></script>
  <script src="../../../../assets/js/vendor/holder.min.js"></script>
  <script>
    Holder.addTheme('thumb', {
      bg: '#55595c',
      fg: '#eceeef',
      text: 'Thumbnail'
    });
  </script>
</body>

</html>