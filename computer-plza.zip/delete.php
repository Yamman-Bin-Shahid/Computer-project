<?php
    $id=$_GET['id'];
    echo $id;
    echo('Ciao');
?>