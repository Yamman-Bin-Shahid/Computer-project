import BSTab from 'bootstrap/js/src/tab';

class Tab extends BSTab {}

export { Tab as default };
//# sourceMappingURL=tab.js.map
