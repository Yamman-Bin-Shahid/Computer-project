<?php

include('phpqrcode/qrlib.php'); 

$ean = $_REQUEST['ean'];

// outputs image directly into browser, as PNG stream
QRcode::png($ean); 

?>